window.COLBY_LINES = [
  {
    "id": "s1-c1",
    "scene": 1,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 2,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "'...love isn't about what you give, isn't about what you make. It's about what you fight for...'"
  },
  {
    "id": "s1-c2",
    "scene": 1,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 2,
    "cueSpeaker": "COLBY",
    "cue": "'...love isn't about what you give, isn't about what you make. It's about what you fight for...'",
    "text": "'...whoever you think is the right for you. I'm him. I am him...'"
  },
  {
    "id": "s1-c3",
    "scene": 1,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 2,
    "cueSpeaker": "COLBY",
    "cue": "'...whoever you think is the right for you. I'm him. I am him...'",
    "text": "'If you focus, and look clearly. I am him. I am, the man for you.'"
  },
  {
    "id": "s1-c4",
    "scene": 1,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 3,
    "cueSpeaker": "COLBY",
    "cue": "'If you focus, and look clearly. I am him. I am, the man for you.'",
    "text": "Hi, my name is Colby Tillman, I'm twenty-nine years old, five-ten, I'm from Brooklyn and this is my audition for the role of 'Callum Hawke'."
  },
  {
    "id": "s1-c5",
    "scene": 1,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 3,
    "cueSpeaker": "COLBY",
    "cue": "Hi, my name is Colby Tillman, I'm twenty-nine years old, five-ten, I'm from Brooklyn and this is my audition for the role of 'Callum Hawke'.",
    "text": "\"Love. It isn't about what you give it isn't about what you make. It's about what you fight for. And I can tell that's something that scares you. So you wait for the solution. You wait for someone to be for you. Whoever you imagine the right man for you is, the vague, blurry image you think up in your head; if you focus and look clearly, it's me. I'm that man. I'm him.\""
  },
  {
    "id": "s6-c1",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 7,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "'It's a beautiful day, you want to enjoy it together?' 'I've never met anyone who also likes to read by the water.' 'Hey, you look like your having a good time with that book. What's it about?'"
  },
  {
    "id": "s6-c2",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 7,
    "cueSpeaker": "COLBY",
    "cue": "'It's a beautiful day, you want to enjoy it together?' 'I've never met anyone who also likes to read by the water.' 'Hey, you look like your having a good time with that book. What's it about?'",
    "text": "Hey."
  },
  {
    "id": "s6-c3",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 7,
    "cueSpeaker": "COLBY",
    "cue": "Hey.",
    "text": "Is it alright if I sit here?"
  },
  {
    "id": "s6-c4",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 7,
    "cueSpeaker": "COLBY",
    "cue": "Is it alright if I sit here?",
    "text": "Looks like you're really into in that book. What's it about?"
  },
  {
    "id": "s6-c5",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 7,
    "cueSpeaker": "COLBY",
    "cue": "Looks like you're really into in that book. What's it about?",
    "text": "Oh."
  },
  {
    "id": "s6-c6",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 8,
    "cueSpeaker": "COLBY",
    "cue": "Oh.",
    "text": "Well, it's a beautiful day. That always makes me feel better."
  },
  {
    "id": "s6-c7",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 8,
    "cueSpeaker": "COLBY",
    "cue": "Well, it's a beautiful day. That always makes me feel better.",
    "text": "You know, I also like reading by the water. Um, you a Pisces? An Aquarius?"
  },
  {
    "id": "s6-c8",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 8,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I'm an atheist.",
    "text": "Okay, that's not mutually excluded but uh- okay so, you must read a lot. Uh, you ever read Shakespeare?"
  },
  {
    "id": "s6-c9",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 8,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "Well, I'm an actor and last year I was actually in a play that you might recognize. I'll let you guess what it is: \"To be or not to be, that is the question.\""
  },
  {
    "id": "s6-c10",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 8,
    "cueSpeaker": "CHRISTIAN",
    "cue": "You played Hamlet?",
    "text": "Well, I played Horatio but in the acting world there's a saying; 'there are no small parts only small actors', so."
  },
  {
    "id": "s6-c11",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 8,
    "cueSpeaker": "CHRISTIAN",
    "cue": "That's cool man.",
    "text": "Yeah. Well. It was nice meeting you. Thanks for the uh, book recommendation."
  },
  {
    "id": "s6-c12",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 8,
    "cueSpeaker": "COLBY",
    "cue": "Yeah. Well. It was nice meeting you. Thanks for the uh, book recommendation.",
    "text": "Okay so, I was just here doing an audition and I saw you and I thought you looked very peaceful so I thought I'd come by and say something."
  },
  {
    "id": "s6-c13",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 9,
    "cueSpeaker": "COLBY",
    "cue": "Okay so, I was just here doing an audition and I saw you and I thought you looked very peaceful so I thought I'd come by and say something.",
    "text": "I didn't mean to bother you or anything."
  },
  {
    "id": "s6-c14",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 9,
    "cueSpeaker": "CHRISTIAN",
    "cue": "It's fine.",
    "text": "My name is Colby, Colby Tillman. Based on the clothes it looks like you're waiting for your shift to start?"
  },
  {
    "id": "s6-c15",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 9,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "Where you from?"
  },
  {
    "id": "s6-c16",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 9,
    "cueSpeaker": "COLBY",
    "cue": "Where you from?",
    "text": "The Bronx?! Why they sent you all the way out here?"
  },
  {
    "id": "s6-c17",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 9,
    "cueSpeaker": "CHRISTIAN",
    "cue": "That's how it is.",
    "text": "So they can send you wherever and you just have to go?"
  },
  {
    "id": "s6-c18",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 9,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "And you gotta be up early in the morning?"
  },
  {
    "id": "s6-c19",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 9,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I don't mind it. I like the peace and quiet of four A.M.",
    "text": "Four?"
  },
  {
    "id": "s6-c20",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 10,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I was at the park over there and then I saw there was a pier here so I came to check it out.",
    "text": "And why? You don't want to be late or, is your home life that bad?"
  },
  {
    "id": "s6-c21",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 10,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I just like the park early in the morning.",
    "text": "Yeah I could never willingly get on the train at four in the morning."
  },
  {
    "id": "s6-c22",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 10,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I guess it is strange.",
    "text": "It's not strange. It's just different. Matter of fact I think it's nice that you're adamant about your peace."
  },
  {
    "id": "s6-c23",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 10,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I don't like that there's a highway cutting right through the park.",
    "text": "The Belt Parkway? Yeah my apartment is like right next to it."
  },
  {
    "id": "s6-c24",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 10,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Is that why you talk so loud?",
    "text": "What?"
  },
  {
    "id": "s6-c25",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 10,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Because of the noise your ears are used to being loud.",
    "text": "Um. I guess so. I never thought about that."
  },
  {
    "id": "s6-c26",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 10,
    "cueSpeaker": "CHRISTIAN",
    "cue": "So you were doing an audition?",
    "text": "Uh yeah I was doing it right over there."
  },
  {
    "id": "s6-c27",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 11,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Why are you auditioning at a pier?",
    "text": "Well the scene takes place by a river so I decided to go full method acting y'know and do my audition next to the river. It's also why I'm dressed like this, these aren't my clothes."
  },
  {
    "id": "s6-c28",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 11,
    "cueSpeaker": "CHRISTIAN",
    "cue": "This is a bay.",
    "text": "What?"
  },
  {
    "id": "s6-c29",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 11,
    "cueSpeaker": "CHRISTIAN",
    "cue": "This is a bay.",
    "text": "It's the same thing."
  },
  {
    "id": "s6-c30",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 11,
    "cueSpeaker": "CHRISTIAN",
    "cue": "What's the movie about?",
    "text": "Uh it's a short film. It's about this guy named Callum Hawke and in the scene he's hanging out by the river and he meets this girl and he's trying to ask her out on a date and he's real romantic to her."
  },
  {
    "id": "s6-c31",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 11,
    "cueSpeaker": "CHRISTIAN",
    "cue": "So, is you coming to talk to me part of your method acting?",
    "text": "Um, No. Not for this part. I just, thought you looked peaceful. Yeah."
  },
  {
    "id": "s6-c32",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 12,
    "cueSpeaker": "CHRISTIAN",
    "cue": "It was nice meeting you.",
    "text": "Yea. Um, Imma guess you gotta take the B42 right? To get out of here? You wanna go together? I'm also on my way to work."
  },
  {
    "id": "s6-c33",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 12,
    "cueSpeaker": "CHRISTIAN",
    "cue": "You gonna go shoot a movie?",
    "text": "I'm not shooting anything at the moment. I'm uh, I'm an actor but I work at a thrift store."
  },
  {
    "id": "s6-c34",
    "scene": 6,
    "sceneTitle": "EXT. BROOKLYN - CANARSIE PIER - MORNING",
    "page": 12,
    "cueSpeaker": "CHRISTIAN",
    "cue": "That's your day job?",
    "text": "Yeah. When I'm working there though I imagine I'm in a movie about my life. And I'm at the part right before the fame hits and right before I dramatically quit my job. So I got a day job but not in a dead end career kinda way more like, I'm at the beginning of my biopic kinda way. You feel that way about your job?"
  },
  {
    "id": "s12-c1",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 23,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "So what would you be doing right now if you didn't have a job?"
  },
  {
    "id": "s12-c2",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 23,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Looking for one.",
    "text": "You ever read Kafka? The story about the guy who turns into a giant beetle?"
  },
  {
    "id": "s12-c3",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 23,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "You're like that."
  },
  {
    "id": "s12-c4",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 23,
    "cueSpeaker": "CHRISTIAN",
    "cue": "You know, I think it's great that you get to do what you love.",
    "text": "Mm. I guesssss. I'm still waiting for my breakout role."
  },
  {
    "id": "s12-c5",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 23,
    "cueSpeaker": "CHRISTIAN",
    "cue": "What role is that?",
    "text": "Like the role I was auditioning for. His name is Callum Hawke. He's a strong, charismatic type. He enters a room and gets the hormones pumping. Both men and women. That's the type of character I want to play."
  },
  {
    "id": "s12-c6",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 24,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Why?",
    "text": "I grew up watching rom-coms. That's the type of movie that made me want to be an actor."
  },
  {
    "id": "s12-c7",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 24,
    "cueSpeaker": "CHRISTIAN",
    "cue": "What's a good romantic comedy?",
    "text": "Hitch. Will Smith is so good in that movie. You ever seen it?"
  },
  {
    "id": "s12-c8",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 24,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I think I might've. I don't remember.",
    "text": "Well you should watch the full movie it's really good. I think romantic comedies aren't as good as they used to be, I think they need to be a little more corny you know? A little more silly, less social commentary."
  },
  {
    "id": "s12-c9",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 24,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I think the same way about video games. Like nowadays games are too long and there's a lot of story. You into gaming?",
    "text": "No, but tell me."
  },
  {
    "id": "s12-c10",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 24,
    "cueSpeaker": "CHRISTIAN",
    "cue": "It's like that where twenty years ago games used to be fun and creative, now it's all serious and realistic.",
    "text": "I think I used to have a Nintendo as a kid."
  },
  {
    "id": "s12-c11",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 24,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Everyone did. I had a DS, a big chunky one.",
    "text": "You know, I think we might actually have one at the store."
  },
  {
    "id": "s12-c12",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 25,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Really?",
    "text": "Yeah."
  },
  {
    "id": "s12-c13",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 25,
    "cueSpeaker": "CHRISTIAN",
    "cue": "That's cool. You get first pick on anything that comes in?",
    "text": "Oh yeah. I take clothes with me all the time."
  },
  {
    "id": "s12-c14",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 25,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Alright. I'm headed this way. It was good meeting you, again.",
    "text": "Nice meeting you, again."
  },
  {
    "id": "s12-c15",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 25,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Maybe we'll bump into each other again. If you ever choose to play a foreman you can audition on my site.",
    "text": "Yeah. We might bump into each other. I think you can do better than that."
  },
  {
    "id": "s12-c16",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 25,
    "cueSpeaker": "CHRISTIAN",
    "cue": "What do you mean?",
    "text": "What I mean is, I'm not someone you meet by chance and I don't believe in coincidences. I'm not coming back to the pier to bump into you again."
  },
  {
    "id": "s12-c17",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 25,
    "cueSpeaker": "COLBY",
    "cue": "What I mean is, I'm not someone you meet by chance and I don't believe in coincidences. I'm not coming back to the pier to bump into you again.",
    "text": "Look, I work a thrift store nearby; keep going straight and then take a right on Crescent. And you keep walking until you see a thrift store. Monday through Friday, I'm there."
  },
  {
    "id": "s12-c18",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 26,
    "cueSpeaker": "CHRISTIAN",
    "cue": "So you want me to come to the thrift store?",
    "text": "Do whatever you want with that information. But if you need some motivation, we do give out discounts to cute customers so... I'm sure you'll find something you like. Do with that what you will."
  },
  {
    "id": "s12-c19",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 26,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I will.",
    "text": "It was nice meeting you Christian Hernandez."
  },
  {
    "id": "s12-c20",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 26,
    "cueSpeaker": "CHRISTIAN",
    "cue": "My name's not Hernandez.",
    "text": "Oh. So what is your name?"
  },
  {
    "id": "s12-c21",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 26,
    "cueSpeaker": "CHRISTIAN",
    "cue": "-Where'd you get Hernandez from?",
    "text": "I must've confused it- what's your name?"
  },
  {
    "id": "s12-c22",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 26,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Torres.",
    "text": "Christian Torres. Okay. Well, you know what do, Christian Torres."
  },
  {
    "id": "s12-c23",
    "scene": 12,
    "sceneTitle": "EXT. BROOKLYN - ATLANTIC AVENUE - MORNING",
    "page": 26,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "Okay, bye."
  },
  {
    "id": "s16-c1",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 30,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "Heyy Mariiiiii."
  },
  {
    "id": "s16-c2",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 30,
    "cueSpeaker": "COLBY",
    "cue": "Heyy Mariiiiii.",
    "text": "How are you? Everything good?"
  },
  {
    "id": "s16-c3",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 30,
    "cueSpeaker": "MARI",
    "cue": "Heyyyy. You're late.",
    "text": "I am and I am sorry, but I have a perfect reason to be late."
  },
  {
    "id": "s16-c4",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 30,
    "cueSpeaker": "MARI",
    "cue": "What?",
    "text": "I think, I might've met, the love of my life!"
  },
  {
    "id": "s16-c5",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 30,
    "cueSpeaker": "COLBY",
    "cue": "I think, I might've met, the love of my life!",
    "text": "Before you start criticizing let me tell you it was so romantic. I was at the pier doing and audition, and then I see this man reading a book and I went up to him and I started talking to him and-"
  },
  {
    "id": "s16-c6",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 31,
    "cueSpeaker": "MARI",
    "cue": "Why were auditioning at the pier?",
    "text": "I was doing a self tape and the scene takes place by a river so I recorded myself by a river."
  },
  {
    "id": "s16-c7",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 31,
    "cueSpeaker": "MARI",
    "cue": "We're not by a river we're by a bay.",
    "text": "It doesn't matter."
  },
  {
    "id": "s16-c8",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 31,
    "cueSpeaker": "MARI",
    "cue": "It doesn't. You're not gonna get cast because you filmed next to some water.",
    "text": "Okay can I continue? So we're talking and it takes a few tries to find out what he's into and I thought I was bothering him for a sec, that would've been bad, but no he's was cool with me approaching him."
  },
  {
    "id": "s16-c9",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 31,
    "cueSpeaker": "MARI",
    "cue": "Is he also cool with you being a psycho?",
    "text": "Something about me appealed to him. His name is Christian, he's a construction worker. He came all the way from The Bronx super early just to read his book at the park. Can you believe that? Waking up early to relax? It sounds like a contradiction. I think that's what appealed to me just how calm he was, he's someone I could see myself settling down with."
  },
  {
    "id": "s16-c10",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 31,
    "cueSpeaker": "MARI",
    "cue": "You are being delusional.",
    "text": "Okay-"
  },
  {
    "id": "s16-c11",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 32,
    "cueSpeaker": "MARI",
    "cue": "Maladaptive. Stupid.",
    "text": "I'm happy for once and that makes me delusional?"
  },
  {
    "id": "s16-c12",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 32,
    "cueSpeaker": "MARI",
    "cue": "Yes.",
    "text": "You're just envious that I have what you can't."
  },
  {
    "id": "s16-c13",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 32,
    "cueSpeaker": "MARI",
    "cue": "Whatever you say.",
    "text": "Okay, let me show you his photos. This will change your mind."
  },
  {
    "id": "s16-c14",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 32,
    "cueSpeaker": "COLBY",
    "cue": "Okay, let me show you his photos. This will change your mind.",
    "text": "Look. Tell me he isn't cute."
  },
  {
    "id": "s16-c15",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 32,
    "cueSpeaker": "MARI",
    "cue": "He didn't give you his IG did he?",
    "text": "In my defense, his username is just his first and last name it was super easy to find."
  },
  {
    "id": "s16-c16",
    "scene": 16,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 32,
    "cueSpeaker": "MARI",
    "cue": "And that makes you a stalker",
    "text": "It's a public account I have right to stalk him."
  },
  {
    "id": "s20-c1",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 39,
    "cueSpeaker": "MARI",
    "cue": "I already found it.",
    "text": "Don't tell me."
  },
  {
    "id": "s20-c2",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 39,
    "cueSpeaker": "MARI",
    "cue": "You have five seconds.",
    "text": "Stop."
  },
  {
    "id": "s20-c3",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 39,
    "cueSpeaker": "MARI",
    "cue": "One........ Two......",
    "text": "Don't."
  },
  {
    "id": "s20-c4",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 40,
    "cueSpeaker": "MARI",
    "cue": "It's here.",
    "text": "Do you think it's a good to send a follow up email to the casting director?"
  },
  {
    "id": "s20-c5",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 40,
    "cueSpeaker": "MARI",
    "cue": "Didn't you just submit it?",
    "text": "Yeah but today's the deadline, I just wanna know if they received my tape."
  },
  {
    "id": "s20-c6",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 40,
    "cueSpeaker": "MARI",
    "cue": "Maybe you should've submitted earlier.",
    "text": "I found the casting call last night. This role really speaks to me I want to make sure it's in."
  },
  {
    "id": "s20-c7",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 40,
    "cueSpeaker": "MARI",
    "cue": "It wouldn't hurt to ask.",
    "text": "Alright, sent."
  },
  {
    "id": "s20-c8",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 40,
    "cueSpeaker": "MARI",
    "cue": "You wanna do another word search?",
    "text": "No."
  },
  {
    "id": "s20-c9",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 40,
    "cueSpeaker": "COLBY",
    "cue": "No.",
    "text": "Oh shit."
  },
  {
    "id": "s20-c10",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 41,
    "cueSpeaker": "MARI",
    "cue": "What?",
    "text": "They replied!"
  },
  {
    "id": "s20-c11",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 41,
    "cueSpeaker": "MARI",
    "cue": "What'd they say?",
    "text": "I don't know I'm too scared to open it. Can you read it for me?"
  },
  {
    "id": "s20-c12",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 41,
    "cueSpeaker": "MARI",
    "cue": "No.",
    "text": "Please."
  },
  {
    "id": "s20-c13",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 41,
    "cueSpeaker": "MARI",
    "cue": "Can you not read an email by yourself?",
    "text": "I'm scared to."
  },
  {
    "id": "s20-c14",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 41,
    "cueSpeaker": "COLBY",
    "cue": "I'm scared to.",
    "text": "Is it good?"
  },
  {
    "id": "s20-c15",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 41,
    "cueSpeaker": "COLBY",
    "cue": "Is it good?",
    "text": "What's it say?"
  },
  {
    "id": "s20-c16",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 41,
    "cueSpeaker": "MARI",
    "cue": "Yo what is wrong with you today?",
    "text": "Fuck."
  },
  {
    "id": "s20-c17",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 42,
    "cueSpeaker": "MARI",
    "cue": "They probably chose someone who doesn't act like a toddler.",
    "text": "Shut up the fuck up Mari."
  },
  {
    "id": "s20-c18",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 42,
    "cueSpeaker": "MARI",
    "cue": "I know you didn't get the role you wanted but you can't be freaking out like that.",
    "text": "Leave me alone."
  },
  {
    "id": "s20-c19",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 42,
    "cueSpeaker": "MARI",
    "cue": "Colby. Get up.",
    "text": "I said leave me alone."
  },
  {
    "id": "s20-c20",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 42,
    "cueSpeaker": "MARI",
    "cue": "This is mad childish this is why no one wants to cast you. Imagine dealing with you on a set.",
    "text": "Sorry."
  },
  {
    "id": "s20-c21",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 43,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Hey.",
    "text": "H- Hey! It's you again!"
  },
  {
    "id": "s20-c22",
    "scene": 20,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 43,
    "cueSpeaker": "COLBY",
    "cue": "H- Hey! It's you again!",
    "text": "Wow. It feels like forever? A lot happens in a few hours. Um, yeah I was just organizing something on the bottom shelf that's why I was on the floor."
  },
  {
    "id": "s23-c1",
    "scene": 23,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 45,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "So, this is where I work. We got lots of stuff nobody wants, lots of dead people's stuff too."
  },
  {
    "id": "s23-c2",
    "scene": 23,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 46,
    "cueSpeaker": "MARI",
    "cue": "Tell him about your audition, how did that go?",
    "text": "Alright Mari, you can't have Christian to yourself. Others want to talk to him too."
  },
  {
    "id": "s23-c3",
    "scene": 23,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 46,
    "cueSpeaker": "MARI",
    "cue": "Yeah. I gotta go move some stuff in the back. I'll let you two be.",
    "text": "She's the owners niece."
  },
  {
    "id": "s26-c1",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 50,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "That's the Nintendo I was talking about."
  },
  {
    "id": "s26-c2",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 50,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I had one like this.",
    "text": "You can have it. If you want."
  },
  {
    "id": "s26-c3",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 50,
    "cueSpeaker": "CHRISTIAN",
    "cue": "It's okay.",
    "text": "You remember that discount for cute customers? It applies here."
  },
  {
    "id": "s26-c4",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 51,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I gotta go.",
    "text": "So soon?"
  },
  {
    "id": "s26-c5",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 51,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I gotta get back to work. I just wanted to say 'hi' real quick.",
    "text": "You on your break?"
  },
  {
    "id": "s26-c6",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 51,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "Okay. Well thanks for coming to say 'hi'."
  },
  {
    "id": "s26-c7",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 51,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I'll see you around.",
    "text": "This is a little weird."
  },
  {
    "id": "s26-c8",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 51,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "How did it feel?"
  },
  {
    "id": "s26-c9",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 51,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Huh?",
    "text": "How did it feel?"
  },
  {
    "id": "s26-c10",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 51,
    "cueSpeaker": "CHRISTIAN",
    "cue": "How did what feel?",
    "text": "How did it feel, deciding to come visit me."
  },
  {
    "id": "s26-c11",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 52,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Out of the ordinary.",
    "text": "Like a movie. I think we should go on a date."
  },
  {
    "id": "s26-c12",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 52,
    "cueSpeaker": "CHRISTIAN",
    "cue": "You want to go on a date with me?",
    "text": "Yes!"
  },
  {
    "id": "s26-c13",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 52,
    "cueSpeaker": "CHRISTIAN",
    "cue": "This feels sudden.",
    "text": "You should be used to it by now. You want to go tonight?"
  },
  {
    "id": "s26-c14",
    "scene": 26,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 52,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Tonight? Very sudden.",
    "text": "We have time today. You can go home, change, and you can pick the restaurant. I'll go to The Bronx."
  },
  {
    "id": "s29-c1",
    "scene": 29,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 56,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "When I take someone out on a date, I like to make a whole day out of it. And we're like most of the way there. Um, am I crazy? You feel this connection right?"
  },
  {
    "id": "s29-c2",
    "scene": 29,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 57,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "Okay I'm not crazy, great. Um. So, that spontaneity, it's important to keep that alive. I think it's good to do things you wouldn't normally do. And I can tell you don't normally do things out of your comfort zone. I can tell you sometimes think what it would be like to go on a date, to have a connection with someone. And it doesn't come. So you wait. You wait for someone to be for you. Whoever you imagine the right man for you is, the vague, blurry image you think up in your head; if you focus and look clearly, it's right in front of you. I'm that guy. I'm him."
  },
  {
    "id": "s29-c3",
    "scene": 29,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 57,
    "cueSpeaker": "COLBY",
    "cue": "Okay I'm not crazy, great. Um. So, that spontaneity, it's important to keep that alive. I think it's good to do things you wouldn't normally do. And I can tell you don't normally do things out of your comfort zone. I can tell you sometimes think what it would be like to go on a date, to have a connection with someone. And it doesn't come. So you wait. You wait for someone to be for you. Whoever you imagine the right man for you is, the vague, blurry image you think up in your head; if you focus and look clearly, it's right in front of you. I'm that guy. I'm him.",
    "text": "Come on. Let's do it. Let's go. You waited enough today."
  },
  {
    "id": "s29-c4",
    "scene": 29,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 57,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Okay.",
    "text": "Yeah?"
  },
  {
    "id": "s29-c5",
    "scene": 29,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 57,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "Okay. Let me give you my number."
  },
  {
    "id": "s29-c6",
    "scene": 29,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 57,
    "cueSpeaker": "COLBY",
    "cue": "Okay. Let me give you my number.",
    "text": "Tonight?"
  },
  {
    "id": "s29-c7",
    "scene": 29,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 57,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah, I'll let you know where.",
    "text": "Thank you."
  },
  {
    "id": "s29-c8",
    "scene": 29,
    "sceneTitle": "INT. BROOKLYN - THRIFT STORE - DAY",
    "page": 58,
    "cueSpeaker": "MARI",
    "cue": "You got what you wanted?",
    "text": "Yes."
  },
  {
    "id": "s35-c1",
    "scene": 35,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 59,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "You come here a lot?"
  },
  {
    "id": "s35-c2",
    "scene": 35,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 59,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yeah.",
    "text": "Is this where you take all of your dates?"
  },
  {
    "id": "s35-c3",
    "scene": 35,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 59,
    "cueSpeaker": "CHRISTIAN",
    "cue": "No, I like come here after work. Usually at the bar.",
    "text": "I like it."
  },
  {
    "id": "s35-c4",
    "scene": 35,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 59,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Honestly I haven't been on a date in years.",
    "text": "Really?"
  },
  {
    "id": "s35-c5",
    "scene": 35,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 59,
    "cueSpeaker": "CHRISTIAN",
    "cue": "It sounds embarrassing I know.",
    "text": "No no no, I'm not judging. I respect that. I've tried going celibate before and it is not easy."
  },
  {
    "id": "s35-c6",
    "scene": 35,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 59,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Um. Not like that. I just, uh, I've never been out with a man before.",
    "text": "What?"
  },
  {
    "id": "s35-c7",
    "scene": 35,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 60,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I'm bi. And, for a long time I've held off on meeting anyone because... I don't know. I never share that side of me.",
    "text": "Like I said, I don't judge. I think it's great that your changing that tonight."
  },
  {
    "id": "s35-c8",
    "scene": 35,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 60,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I don't mean to kill the vibe I just needed to get that off my chest.",
    "text": "No no, you're good, you're good don't worry. Listen. Being humble is not it. Alright if you're on a date with me then you're on a date with me. I want to listen to anything you wanna say."
  },
  {
    "id": "s38-c1",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 62,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "If I'm with someone I need to be front and center. I've been with too many men who just use me and then treat me like we never met before."
  },
  {
    "id": "s38-c2",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 63,
    "cueSpeaker": "COLBY",
    "cue": "If I'm with someone I need to be front and center. I've been with too many men who just use me and then treat me like we never met before.",
    "text": "What I need is to be somebody's only. I'm not a substitute, I'm not an understudy. I'm the showstopper, y'know. I'm Colby Tillman."
  },
  {
    "id": "s38-c3",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 63,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Is that your real name? Colby Tillman?",
    "text": "Does it sound made up?"
  },
  {
    "id": "s38-c4",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 63,
    "cueSpeaker": "CHRISTIAN",
    "cue": "No, I was just gonna say it sounds like a perfect name for an actor. Like I can imagine seeing it on TV one day. 'And the Oscar goes to... Colby Tillman!'",
    "text": "It is a stage name. It comes from my grandfather's name and my mom's maiden name."
  },
  {
    "id": "s38-c5",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 63,
    "cueSpeaker": "CHRISTIAN",
    "cue": "What's your real name?",
    "text": "That is a secret."
  },
  {
    "id": "s38-c6",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 63,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Sorry I don't mean to be privy.",
    "text": "As an actor you have to separate as much of yourself from the character you have to believe that the person your portraying is a real living person and you can't involve your own biases. Then the illusion falls apart and people can tell that he's fake. And- I like when people call me Colby. It's like my real name at this point."
  },
  {
    "id": "s38-c7",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 63,
    "cueSpeaker": "COLBY",
    "cue": "As an actor you have to separate as much of yourself from the character you have to believe that the person your portraying is a real living person and you can't involve your own biases. Then the illusion falls apart and people can tell that he's fake. And- I like when people call me Colby. It's like my real name at this point.",
    "text": "You know I like your name too. Christian Torres."
  },
  {
    "id": "s38-c8",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 64,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Thank you. I was named after my dad so, everyone calls me Junior.",
    "text": "And how do you feel about that? Being tied to your dad's name?"
  },
  {
    "id": "s38-c9",
    "scene": 38,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 64,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Well. Me and him are close. He moved to DR but, we talk on the phone. It's kinda nice getting old. Um, me and him relate to each other more. You know we can complain about work and our backs hurting.",
    "text": "Well that's great! Yeah, it's great you two get along so well."
  },
  {
    "id": "s41-c1",
    "scene": 41,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 65,
    "cueSpeaker": "START",
    "cue": "START",
    "text": "Did today cure your depression?"
  },
  {
    "id": "s41-c2",
    "scene": 41,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 66,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I'm not depressed.",
    "text": "Oh. So why were you reading how to overcome it?"
  },
  {
    "id": "s41-c3",
    "scene": 41,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 66,
    "cueSpeaker": "CHRISTIAN",
    "cue": "It's my sister. We live together but she doesn't want to talk to me and I don't know what to do.",
    "text": "Why not?"
  },
  {
    "id": "s41-c4",
    "scene": 41,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 66,
    "cueSpeaker": "CHRISTIAN",
    "cue": "That's the thing. We've lived together all our lives but, somewhere along the way I lost her. And, I think she's depressed or something. I think she needs someone to talk to but I don't how to bring it up. And since our parents left I've just been working my ass off trying to pay for everything and she doesn't want to get a job.",
    "text": "Tell her to go get a job or she can kick rocks."
  },
  {
    "id": "s41-c5",
    "scene": 41,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 66,
    "cueSpeaker": "CHRISTIAN",
    "cue": "No. I just want her to support herself. When I was growing up that's how it was I had to, get a job I had to help around the house I was helping my parents with documents, court papers. When she was in school I had to be the one to help her even graduate. And, shit. I barely had any time for myself. I should be in bed, resting for work tomorrow. It's nice being here with you, on a date.",
    "text": "Me too."
  },
  {
    "id": "s41-c6",
    "scene": 41,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 67,
    "cueSpeaker": "CHRISTIAN",
    "cue": "But, before we go any further I want to make something clear about me.",
    "text": "Tell me."
  },
  {
    "id": "s44-c1",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 68,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I had a good time with you but, I don't think I can be in a relationship right now.",
    "text": "Say that again?"
  },
  {
    "id": "s44-c2",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 68,
    "cueSpeaker": "CHRISTIAN",
    "cue": "I'm hearing what you're saying about what you want out of a relationship and your expectations but I can't be that. I mean this super politely.",
    "text": "Don't try to be humble. No. You're great. You're a great guy what do you mean you can't be what I'm looking for, you already are?"
  },
  {
    "id": "s44-c3",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 69,
    "cueSpeaker": "CHRISTIAN",
    "cue": "That's not me. I got too much in my life right now.",
    "text": "I don't understand. So tell me when would you be ready? When are you gonna have time for a relationship?"
  },
  {
    "id": "s44-c4",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 69,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Not right now-",
    "text": "When you find a better job? When you're bitch ass sister stops being a freeloader and moves out? What needs to happen for you to be in a relationship?"
  },
  {
    "id": "s44-c5",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 69,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Yo don't be like that.",
    "text": "You agreed to be on this date. You came to me at my job looking for me, you chose this restaurant to eat in, which by the way took three trains for me to get here!"
  },
  {
    "id": "s44-c6",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 69,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Okay what the fuck's going on. Why are you acting this way?",
    "text": "I'm not acting I'm being honest why do you lead me on and then all of a sudden you don't want me anymore?"
  },
  {
    "id": "s44-c7",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 69,
    "cueSpeaker": "CHRISTIAN",
    "cue": "This makes no sense we only just met today-",
    "text": "Like, this is literal manipulation. This is bipolar behavior."
  },
  {
    "id": "s44-c8",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 70,
    "cueSpeaker": "CHRISTIAN",
    "cue": "No- you're being- how the fuck are you gonna come here and act like your my friend and then start accusing me of manipulating you? And calling my sister a bitch?",
    "text": "You're being like everyone else I take you on this date and I treat you nice. You just forgot to take me home and fuck me. That's the only thing different about you!"
  },
  {
    "id": "s44-c9",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 70,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Alright I'm done. Fuck this date fuck this dinner. Fuck this whatever you got going on.",
    "text": "No, please don't go, I'm sorry I'm sorry if I said anything wrong, I'm sorry."
  },
  {
    "id": "s44-c10",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 70,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Let go of me.",
    "text": "Please I need you to stay."
  },
  {
    "id": "s44-c11",
    "scene": 44,
    "sceneTitle": "INT. BROOKLYN - RESTAURANT - EVENING",
    "page": 70,
    "cueSpeaker": "CHRISTIAN",
    "cue": "Let fucking go of me.",
    "text": "You have no idea what it's like to be alone! You don't know what that's like!"
  }
];
